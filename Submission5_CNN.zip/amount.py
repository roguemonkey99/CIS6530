def find_largest_number_of_commas(file_path):
    max_commas = 0

    with open(file_path, 'r', encoding='utf-8') as file:
        for line in file:
            num_commas = line.count(',')
            if num_commas > max_commas:
                max_commas = num_commas

    print(max_commas)

txt_file_path = 'output.csv'
find_largest_number_of_commas(txt_file_path)

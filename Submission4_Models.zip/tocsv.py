import os
import csv
from collections import defaultdict

def read_opcodes_from_file(file_path):
    opcodes = []
    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line.startswith('['):
                continue
            if line:
                opcodes.append(line)
    return ", ".join(opcodes)

def extract_opcodes_to_csv(root_dir, output_csv, apt_mapping_file):
    data = []
    apt_labels = {}
    label_counter = 1
    apt_group_counts = defaultdict(int)

    for root, dirs, files in os.walk(root_dir):
        for file in files:
            if file.endswith('.opcode'):
                apt_group = os.path.relpath(root, root_dir).split(os.sep)[0]
                if apt_group not in apt_labels:
                    apt_labels[apt_group] = label_counter
                    label_counter += 1

                file_path = os.path.join(root, file)
                opcodes = read_opcodes_from_file(file_path)
                
                if opcodes:
                    data.append([opcodes, apt_labels[apt_group]])
                    apt_group_counts[apt_group] += 1
                else:
                    print(f"Skipping empty opcode file: {file_path}")

    if data:
        with open(output_csv, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['Opcodes', 'APT'])
            writer.writerows(data)
        print(f"CSV file created at: {output_csv}")

        with open(apt_mapping_file, 'w', newline='') as mapping_file:
            writer = csv.writer(mapping_file)
            writer.writerow(['APT Group', 'Label', 'Count'])
            for apt_group, label in apt_labels.items():
                writer.writerow([apt_group, label, apt_group_counts[apt_group]])
        print(f"APT mapping file created at: {apt_mapping_file}")
    else:
        print("No opcode data found in the specified directory.")

root_dir = '.'
output_csv = 'output.csv'
apt_mapping_file = 'apt_mapping.csv'
extract_opcodes_to_csv(root_dir, output_csv, apt_mapping_file)
